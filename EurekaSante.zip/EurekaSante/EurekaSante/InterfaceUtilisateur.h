#ifndef INTERFACE_UTILISATEUR
#define INTERFACE_UTILISATEUR

#include "Reglages.h"

int main();

#endif // INTERFACE_UTILISATEUR